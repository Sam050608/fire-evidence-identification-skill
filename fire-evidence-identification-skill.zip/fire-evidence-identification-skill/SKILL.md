---
name: fire-evidence-identification-skill
description: >
  Chinese fire-case physical-evidence identification (涉火案件物证鉴定技术) structured
  knowledge base built from 13 course slide decks. Covers thermal analysis (TG/DTG/DSC/DTA),
  flammable liquid and burn-residue identification (快速检测 / GC / GC-MS / HPLC / UV / IR),
  electric fire evidence identification (宏观法 / 剩磁法 / 金相法 / SEM-EDS / 成分分析),
  fire-scene DNA STR typing, and fiber/hair thermal damage. 13 on-demand chapters with
  frameworks, thresholds, instrument procedures and worked cases. Use when identifying
  physical evidence in fire cases, planning instrumental analysis, interpreting lab results
  for fire origin/cause determination, or studying 涉火案件物证鉴定技术.
generated: 2026-09-09
source: 《涉火案件物证鉴定技术》课程讲义（火灾物证技术鉴定，13 个 PDF 课件；含 GB/T 13464-2008、GB/T 18294、GB/T 16840.5、GB 16840.6 等标准相关内容）
---

# 涉火案件物证鉴定技术 (Fire-case Physical Evidence Identification)

> 课程体系：热分析（TG/DTG/DSC/DTA）→ 易燃液体及其燃烧残留物（快速检测/GC/GC-MS/HPLC/UV/IR）→ 电气火灾物证鉴定（宏观/剩磁/金相/SEM-EDS/成分）→ 火场 DNA 嫌疑人认定 → 纤维/毛发热损伤研究。

## How to Use

- **无参数** — 加载本页核心框架与决策规则
- **问主题**（如 "一次短路熔痕怎么鉴别" "汽油残留怎么检" "DNA 多少度会降解"）— 读取对应章节文件
- **指定章节**（如 ch09）— 加载该章深入学习
- **问 "有哪些章节"** — 查看 Chapter Index

---

## 核心框架与思维模型

### 一、热分析（Ch1–Ch2）

- **ICTА 1977 热分析定义**：在程序控制温度下测量物质物理性质与温度关系的一类技术；所测物理量 F=f(T)，温度是时间函数 T=P(t)。**Use when** 界定"什么算热分析"、跨仪器统一叙述。
- **TG / DTG 判读链**：TG 平台→下降段→平台；DTG 峰顶点=最大失重速率点（对应 TG 拐点），峰数=台阶数，峰面积∝失重量。起始/终止温度用外延基线-切线交点或 TG-x% 判读。**Use when** 评价材料热稳定性、判断挥发/分解/气固反应。
- **DSC / DTA**：测热效应；DSC 峰面积 ΔH=K·A；放热峰/吸热峰方向随仪器定义不同；升温速率 5–20 ℃/min（越快分辨率下降）。**Use when** 判断自燃倾向（如过硫酸铵、浸油棉花）、化学反应/相变温度。
- **联用技术**：TG-DTA、TG-DSC、DTA-GC、TG-DTA-GC-MS、EGA-MS/FTIR —— 同时获得热效应、组成与逸出气体信息。
- **GB/T 13464-2008**《物质热稳定性的热分析试验方法》：火灾物证热稳定性试验的标准依据，须注明气氛与程序控温条件才能比较曲线。

### 二、易燃液体与色谱（Ch3–Ch6）

- **鉴定链（Ch3）**：现场发现/提取（顶空、溶剂提取、活性炭吸附等）→ 快速检测（嗅觉/检气管/便携检测/显色）→ 色谱-质谱确认 → 特征峰/离子 → 认定汽油/煤油/柴油/油漆稀料等助燃剂。液体的流淌痕、低位燃烧、坑洞、木纹理是现场重要线索。
- **GC（Ch4）**：固定相+流动相（载气）+色谱柱+检测器；分配系数 K=Cs/Cg，K 越大保留越强；填充柱（内径2–4mm/长1–10m）与毛细管柱（0.2–0.5mm/10–300m）；检测器：FID（质量型通用）、TCD（浓度型）、ECD（选择型）、FPD（选择型）。
- **色谱理论（Ch5）**：塔板理论 n=L/H，有效塔板数/高度；速率理论 Van Deemter H=A+B/u+C·u，最佳流速；分离度 R：R=1→98% 分离，R=1.5→99.7%，R>1.5 完全分离；峰宽 W1/2=2.35σ、Wb=4σ、面积 A=1.065h·W1/2。
- **GC-MS（Ch6）**：EI 离子源、高真空、TIC/EIC 联用判读；汽油/柴油/油漆稀料燃烧残留物用特征离子 m/z 与谱库比对（GB/T 18294）；主要芳香/稠环特征峰在源课件中以 (OCR 待核) 标注，实际判读需以标准谱库为准。
- **HPLC（Ch6）**：液相色谱（反相为主），UV 检测器；适合不易挥发/热不稳定组分；与 GC 互补。
- **紫外/红外光谱**：辅助鉴别官能团/组分（如 FTIR 追踪 NH/NH₂、CO 随温度演变）。

### 三、电气火灾物证（Ch7–Ch10）

- **五类鉴定方法（Ch7）**：宏观法（形态/外观）、剩磁法、金相法（组织）、微观形貌法（SEM）、成分分析法（EDS），按"先宏观后微观、先定性后定量"组合使用。
- **物证类型与判据**：
  - **一次短路**：火灾前短路；熔痕界线明显、细小柱状/胞状晶、气孔小而少、喷溅珠广。
  - **二次短路**：火灾中受热短路；气孔大而多、粗大柱状晶/胞状晶、界线不明显。
  - **过电流（过负荷）**：绝缘内层老化/炭化、全线均匀结疤断节、整根再结晶。
  - **接触不良**：局部高温、插接件烧蚀、电烧蚀痕迹立体感强。
  - **火烧熔痕**：外部烧焦紧粘、过渡区、等轴晶、无气孔。
- **GB 16840.6 SEM 分类表（Ch10）**：一次短路=抛物线卵形花样/树枝晶柱状晶；二次短路=蜂窝状花样/胞状晶亚结构/孔洞较多；火烧=网格状花样/等轴晶晶界粗；过载=礁石状花样/有缩孔。
- **EDS 成分分析（Ch10）**：特征 X 射线→按能量分谱→定性（自动寻峰）+定量（相对含量）；溅金镀膜引入的 Au 峰不计入试样成分。示例：炭化红松随温度升高 C 含量上升、O 下降（常温→900℃ 表）。
- **金属材料（Ch8）**：晶体结构（七大晶系、晶胞/晶粒/晶界/缺陷）；结晶=过冷度+形核+长大（铸锭三晶区）；受热=回复→再结晶→晶粒长大；退火/正火/淬火/回火；熔点与强度下降规律是"受热温度标尺"。

### 四、火场DNA（Ch11）

- **STR 分型三级判定**：完整 DNA 图谱 / 部分 DNA 图谱 / 无 DNA 图谱（GeneMapper ID-X 判读）。
- **温度-时间判据**：≤150℃ 10 min 或 100℃ 60 min → 可获完整图谱；150℃ 20 min 或 180℃ 5 min → 部分图谱；180℃ 20 min 或 200℃ 60 min → 无图谱。
- **血迹形貌辅助**：≤180℃ 黑色裂纹（倾向完整）；200℃ 金属光泽球状鼓包（倾向部分）；220℃ 鼓包尺寸显著增大（倾向无）。
- **分子机理**：键能越低越先断——C-N 305 → C-O 326 → C-C 332 → P-O 410 → C-H 414 → C=N 615 → C=O 728 kJ/mol（表 6.4 另有 kcal/mol 数据）。
- **证据使用**：无 DNA 图谱 ≠ 排除嫌疑人，可能是热降解所致；报告须注明受热条件与形貌。

### 五、纤维与毛发热损伤（Ch12–Ch13）

- **纤维（Ch12）**：天然（棉/麻）与化学纤维结构不同；SEM 看表面/横截面，TG/DSC 看热性能，FTIR 看官能团；热损=熔融、炭化、收缩、焦化；端部熔融、龟裂、气泡等痕迹可重建受热条件。
- **毛发（Ch13）**：角质蛋白、毛小皮/皮质/髓质；Hot Stage 逐级加热定位临界温度；**化学腐蚀 vs 热作用**：酸碱→碎裂/软化无弹性、稀释减弱且不卷缩；热作用→卷缩、有弹性（部分易碎）；内部髓质起泡、鳞片 V 字型分离是热损标志；样本来源分类→个体识别（爆炸现场遗留毛发等）。

### 六、通用方法论

- **多手段互证**：宏观→金相→SEM→EDS→色谱/质谱→DNA/形貌，任何单一手段不认定。
- **证据链**：提取（GB/T 16840.5 等）→ 检测标准 → 特征比对 → 排除其他可能 → 形成鉴定意见。
- **受热条件重建**：所有"温度-时间"记录体（TG/DTG、DSC、金属组织、DNA、纤维/毛发）联合给出温度场与时间轴。
- **OCR 待核**：本技能由课件 OCR 生成，个别表格行列/数值标注 (OCR 待核)，引用前回原课件或标准核对。

---

## Chapter Index

| # | Title | Key Frameworks |
|---|-------|----------------|
| [ch01](chapters/ch01-thermal-analysis-overview-tg-dtg.md) | 热分析技术简介与热重法（TG/DTG） | ICTA 定义、TG/DTG 判读、外延温度、分步分解 |
| [ch02](chapters/ch02-dsc-principles-applications.md) | 差示扫描量热法（DSC）及其应用 | DSC 定义、零位平衡、峰面积-焓变、自燃案例 |
| [ch03](chapters/ch03-flammable-liquid-residue-identification.md) | 易燃液体及其燃烧残留物鉴定方法 | 快速检测、提取、GC/GC-MS/HPLC/UV/IR、现场痕迹 |
| [ch04](chapters/ch04-gas-chromatography-method.md) | 气相色谱法 | 色谱三分类、GC 组成、检测器、分配系数 K |
| [ch05](chapters/ch05-gas-chromatography-theory.md) | 气相色谱理论 | 流出曲线、塔板理论、Van Deemter、分离度 R |
| [ch06](chapters/ch06-gc-ms-and-hplc.md) | 气相色谱质谱法、高效液相色谱法 | GC-MS TIC/EIC、特征离子、HPLC 对比 |
| [ch07](chapters/ch07-electrical-fire-evidence-overview.md) | 电气火灾物证鉴定方法概述 | 五类物证、宏观/剩磁/金相/SEM/EDS、提取框架 |
| [ch08](chapters/ch08-metal-materials-basics.md) | 金属材料学基本理论 | 晶体结构、结晶、受热再结晶、热处理 |
| [ch09](chapters/ch09-metallographic-analysis.md) | 金相分析方法 | 试样制备、组织观察、短路/火烧金相判别 |
| [ch10](chapters/ch10-electron-microscopy-analysis.md) | 电子显微分析（SEM/EDS） | SEM 形貌、GB16840.6 熔痕分类、EDS 成分 |
| [ch11](chapters/ch11-fire-scene-dna.md) | 火场DNA分析 | STR 三级图谱、温度-时间判据、键能断裂 |
| [ch12](chapters/ch12-fiber-thermal-damage.md) | 纤维热损伤鉴定 | 纤维结构、SEM/TG/FTIR、热损痕迹 |
| [ch13](chapters/ch13-hair-thermal-damage.md) | 毛发热损伤鉴定 | 毛发结构、Hot Stage、化学腐蚀 vs 热作用 |

## Topic Index

- **TG / DTG / 热重** → ch01
- **DSC / DTA / 差热分析** → ch01, ch02
- **热稳定性 / GB/T 13464-2008** → ch01, ch02
- **易燃液体 / 助燃剂 / 燃烧残留物** → ch03, ch06
- **快速检测方法** → ch03
- **气相色谱 GC / 色谱柱 / 检测器** → ch03, ch04
- **分配系数 K / 保留参数** → ch04, ch05
- **塔板理论 / 速率理论 / Van Deemter** → ch05
- **分离度 R** → ch05
- **GC-MS / 质谱 / TIC / EIC / 特征离子** → ch06
- **HPLC / 液相色谱** → ch06
- **紫外光谱 / 红外光谱 / FTIR** → ch03, ch06, ch12, ch13
- **电气火灾物证 / 五类鉴定方法** → ch07
- **宏观法 / 剩磁法** → ch07
- **金属材料学 / 晶体结构 / 结晶 / 受热变化** → ch08
- **金相法 / 金相试样 / 晶粒度** → ch09
- **一次短路 / 二次短路 / 过电流 / 火烧熔痕** → ch09, ch10
- **SEM / 扫描电镜 / 微观形貌** → ch10
- **EDS / X 射线能谱 / 成分分析** → ch10
- **GB16840.6 熔痕分类** → ch10
- **火场DNA / STR / GeneMapper** → ch11
- **DNA 热降解 / 温度-时间判据** → ch11
- **纤维热损伤 / 纤维结构 / 助燃剂放火** → ch12
- **毛发热损伤 / Hot Stage / 化学腐蚀 vs 热作用** → ch13
- **受热条件重建 / 温度场** → ch01, ch11, ch12, ch13
- **证据链 / 交叉印证** → ch07, ch09, ch10, ch11

## Supporting Files

- [glossary.md](glossary.md) — 全部关键术语与定义（按章节）
- [patterns.md](patterns.md) — 可复用的鉴定流程与模式
- [cheatsheet.md](cheatsheet.md) — 决策规则、阈值表、快速信号

---

## Scope & Limits

本技能仅覆盖《涉火案件物证鉴定技术》13 份课件内容（OCR 提取，628 页）。实际操作需结合实验室仪器、标准方法（GB/T 13464-2008、GB/T 18294、GB/T 16840.5、GB 16840.6）与样品前处理；OCR 个别表格/数值以「(OCR 待核)」标注，引用前应回原课件核对。相关既有技能：fire-investigation-skill（火灾调查程序）、fire-trace-evidence-skill（火灾痕迹）、forensic-medicine-skill（法医学）。
